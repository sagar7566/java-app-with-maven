# java-app-with-maven
sample java project with maven
